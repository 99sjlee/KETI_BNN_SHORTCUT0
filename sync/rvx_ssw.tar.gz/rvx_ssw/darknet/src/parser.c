#include "ervp_malloc.h"
#include "ervp_printf.h"
#include "ervp_assert.h"
#include "texpar_list.h"
#include "texpar_api.h"

#include <stdio.h>
#include <string.h>
#include "ervp_stdlib.h"
#include <stdint.h>

#include "activation_layer.h"
#include "activations.h"
#include "avgpool_layer.h"
#include "batchnorm_layer.h"
#include "blas.h"
#include "connected_layer.h"
#include "convolutional_layer.h"
#include "cost_layer.h"
#include "crnn_layer.h"
#include "crop_layer.h"
#include "detection_layer.h"
#include "dropout_layer.h"
#include "gru_layer.h"
#include "local_layer.h"
#include "lstm_layer.h"
#include "conv_lstm_layer.h"
#include "maxpool_layer.h"
#include "normalization_layer.h"
#include "parser.h"
#include "region_layer.h"
#include "reorg_layer.h"
#include "reorg_old_layer.h"
#include "rnn_layer.h"
#include "route_layer.h"
#include "shortcut_layer.h"
#include "softmax_layer.h"
#include "utils.h"
#include "upsample_layer.h"
#include "version.h"
#include "yolo_layer.h"

LAYER_TYPE string_to_layer_type(char * type)
{

    if (strcmp(type, "[shortcut]")==0) return SHORTCUT;
    if (strcmp(type, "[crop]")==0) return CROP;
    if (strcmp(type, "[cost]")==0) return COST;
    if (strcmp(type, "[detection]")==0) return DETECTION;
    if (strcmp(type, "[region]")==0) return REGION;
    if (strcmp(type, "[yolo]") == 0) return YOLO;
    if (strcmp(type, "[local]")==0) return LOCAL;
    if (strcmp(type, "[conv]")==0
            || strcmp(type, "[convolutional]")==0) return CONVOLUTIONAL;
    if (strcmp(type, "[activation]")==0) return ACTIVE;
    if (strcmp(type, "[net]")==0
            || strcmp(type, "[network]")==0) return NETWORK;
    if (strcmp(type, "[crnn]")==0) return CRNN;
    if (strcmp(type, "[gru]")==0) return GRU;
    if (strcmp(type, "[lstm]")==0) return LSTM;
    if (strcmp(type, "[conv_lstm]") == 0) return CONV_LSTM;
    if (strcmp(type, "[rnn]")==0) return RNN;
    if (strcmp(type, "[conn]")==0
            || strcmp(type, "[connected]")==0) return CONNECTED;
    if (strcmp(type, "[max]")==0
            || strcmp(type, "[maxpool]")==0) return MAXPOOL;
    if (strcmp(type, "[reorg3d]")==0) return REORG;
    if (strcmp(type, "[reorg]") == 0) return REORG_OLD;
    if (strcmp(type, "[avg]")==0
            || strcmp(type, "[avgpool]")==0) return AVGPOOL;
    if (strcmp(type, "[dropout]")==0) return DROPOUT;
    if (strcmp(type, "[lrn]")==0
            || strcmp(type, "[normalization]")==0) return NORMALIZATION;
    if (strcmp(type, "[batchnorm]")==0) return BATCHNORM;
    if (strcmp(type, "[soft]")==0
            || strcmp(type, "[softmax]")==0) return SOFTMAX;
    if (strcmp(type, "[route]")==0) return ROUTE;
    if (strcmp(type, "[upsample]") == 0) return UPSAMPLE;
    return BLANK;
}

void parse_data(char *data, float *a, int n)
{
    int i;
    if(!data) return;
    char *curr = data;
    char *next = data;
    int done = 0;
    for(i = 0; i < n && !done; ++i){
        while(*++next !='\0' && *next != ',');
        if(*next == '\0') done = 1;
        *next = '\0';
        sscanf(curr, "%g", &a[i]);
        curr = next+1;
    }
}

typedef struct size_params{
    int batch;
    int inputs;
    int h;
    int w;
    int c;
    int index;
    int time_steps;
    network net;
} size_params;

local_layer parse_local(texpar_list_t *options, size_params params)
{
    int n = texpar_find_int(options, "filters",1);
    int size = texpar_find_int(options, "size",1);
    int stride = texpar_find_int(options, "stride",1);
    int pad = texpar_find_int(options, "pad",0);
    char *activation_s = texpar_find_str(options, "activation", "logistic");
    ACTIVATION activation = get_activation(activation_s);

    int batch,h,w,c;
    h = params.h;
    w = params.w;
    c = params.c;
    batch=params.batch;
    if(!(h && w && c)) error("Layer before local layer must output image.");

    local_layer layer = make_local_layer(batch,h,w,c,n,size,stride,pad,activation);

    return layer;
}

convolutional_layer parse_convolutional(texpar_list_t *options, size_params params)
{   
    int quantization_type = texpar_find_int_quiet(options, "quantization_type",0);
    float quantization_layer_scale = texpar_find_float_quiet(options, "quantization_layer_scale",0);
    int quantization_layer_zeropoint = texpar_find_int_quiet(options, "quantization_layer_zeropoint",1);
    int n = texpar_find_int(options, "filters",1);
    int groups = texpar_find_int_quiet(options, "groups", 1);
    int size = texpar_find_int(options, "size",1);
    int stride = texpar_find_int(options, "stride",1);
    int pad = texpar_find_int_quiet(options, "pad",0);
    int padding = texpar_find_int_quiet(options, "padding",0);
    if(pad) padding = size/2;
    char *activation_s = texpar_find_str(options, "activation", "logistic");
    ACTIVATION activation = get_activation(activation_s);
    int batch,h,w,c;
    h = params.h;
    w = params.w;
    c = params.c;
    //printf("h w c :%d:%d:%d\n",h,w,c);
    batch=params.batch;
    if(!(h && w && c)) error("Layer before convolutional layer must output image.");
    int batch_normalize = texpar_find_int_quiet(options, "batch_normalize", 0);
    int binary = texpar_find_int_quiet(options, "binary", 0);
    int xnor = texpar_find_int_quiet(options, "xnor", 0);
    int use_bin_output = texpar_find_int_quiet(options, "bin_output", 0);
    convolutional_layer layer =  {0};
    if (quantization_type){
        printf("make q_conv_layer init \n");
        layer = make_quantized_convolutional_layer(batch,1,h,w,c,n,groups,size,stride,padding,activation, batch_normalize, binary, xnor, params.net.adam, use_bin_output, params.index,quantization_type);
        layer.quantization_layer_scale= quantization_layer_scale;
        layer.quantization_layer_zeropoint= quantization_layer_zeropoint;
        printf("make q_conv_layer done \n");
    }
    else{
        layer = make_convolutional_layer(batch,1,h,w,c,n,groups,size,stride,padding,activation, batch_normalize, binary, xnor, params.net.adam, use_bin_output, params.index);
    }
    layer.flipped = texpar_find_int_quiet(options, "flipped", 0);
    layer.dot = texpar_find_float_quiet(options, "dot", 0);

    if(params.net.adam){
        layer.B1 = params.net.B1;
        layer.B2 = params.net.B2;
        layer.eps = params.net.eps;
    }

    return layer;
}

layer parse_crnn(texpar_list_t *options, size_params params)
{
    int size = texpar_find_int_quiet(options, "size", 3);
    int stride = texpar_find_int_quiet(options, "stride", 1);
    int pad = texpar_find_int_quiet(options, "pad", 0);
    int padding = texpar_find_int_quiet(options, "padding", 0);
    if (pad) padding = size / 2;

    int output_filters = texpar_find_int(options, "output",1);
    int hidden_filters = texpar_find_int(options, "hidden",1);
    int groups = texpar_find_int_quiet(options, "groups", 1);
    char *activation_s = texpar_find_str(options, "activation", "logistic");
    ACTIVATION activation = get_activation(activation_s);
    int batch_normalize = texpar_find_int_quiet(options, "batch_normalize", 0);
    int xnor = texpar_find_int_quiet(options, "xnor", 0);

    layer l = make_crnn_layer(params.batch, params.h, params.w, params.c, hidden_filters, output_filters, groups, params.time_steps, size, stride, padding, activation, batch_normalize, xnor);

    l.shortcut = texpar_find_int_quiet(options, "shortcut", 0);

    return l;
}

layer parse_rnn(texpar_list_t *options, size_params params)
{
    int output = texpar_find_int(options, "output",1);
    int hidden = texpar_find_int(options, "hidden",1);
    char *activation_s = texpar_find_str(options, "activation", "logistic");
    ACTIVATION activation = get_activation(activation_s);
    int batch_normalize = texpar_find_int_quiet(options, "batch_normalize", 0);
    int logistic = texpar_find_int_quiet(options, "logistic", 0);

    layer l = make_rnn_layer(params.batch, params.inputs, hidden, output, params.time_steps, activation, batch_normalize, logistic);

    l.shortcut = texpar_find_int_quiet(options, "shortcut", 0);

    return l;
}

layer parse_gru(texpar_list_t *options, size_params params)
{
    int output = texpar_find_int(options, "output",1);
    int batch_normalize = texpar_find_int_quiet(options, "batch_normalize", 0);

    layer l = make_gru_layer(params.batch, params.inputs, output, params.time_steps, batch_normalize);

    return l;
}

layer parse_lstm(texpar_list_t *options, size_params params)
{
    int output = texpar_find_int(options, "output",1);
    int batch_normalize = texpar_find_int_quiet(options, "batch_normalize", 0);

    layer l = make_lstm_layer(params.batch, params.inputs, output, params.time_steps, batch_normalize);

    return l;
}

layer parse_conv_lstm(texpar_list_t *options, size_params params)
{
    // a ConvLSTM with a larger transitional kernel should be able to capture faster motions
    int size = texpar_find_int_quiet(options, "size", 3);
    int stride = texpar_find_int_quiet(options, "stride", 1);
    int pad = texpar_find_int_quiet(options, "pad", 0);
    int padding = texpar_find_int_quiet(options, "padding", 0);
    if (pad) padding = size / 2;

    int output_filters = texpar_find_int(options, "output", 1);
    int groups = texpar_find_int_quiet(options, "groups", 1);
    char *activation_s = texpar_find_str(options, "activation", "LINEAR");
    ACTIVATION activation = get_activation(activation_s);
    int batch_normalize = texpar_find_int_quiet(options, "batch_normalize", 0);
    int xnor = texpar_find_int_quiet(options, "xnor", 0);
    int peephole = texpar_find_int_quiet(options, "peephole", 0);

    layer l = make_conv_lstm_layer(params.batch, params.h, params.w, params.c, output_filters, groups, params.time_steps, size, stride, padding, activation, batch_normalize, peephole, xnor);

    l.state_constrain = texpar_find_int_quiet(options, "state_constrain", params.time_steps * 32);
    l.shortcut = texpar_find_int_quiet(options, "shortcut", 0);

    return l;
}

connected_layer parse_connected(texpar_list_t *options, size_params params)
{
    int quantization_type = texpar_find_int_quiet(options, "quantization_type",0);
    float quantization_layer_scale = texpar_find_float_quiet(options, "quantization_layer_scale",0);
    int quantization_layer_zeropoint = texpar_find_int_quiet(options, "quantization_layer_zeropoint",1);
    int output = texpar_find_int(options, "output",1);
    char *activation_s = texpar_find_str(options, "activation", "logistic");
    ACTIVATION activation = get_activation(activation_s);
    int batch_normalize = texpar_find_int_quiet(options, "batch_normalize", 0);
    if(quantization_type){
        connected_layer layer = make_quantized_connected_layer(params.batch, 1, params.inputs, output, activation, batch_normalize,quantization_type);        
        layer.quantization_layer_scale= quantization_layer_scale;
        layer.quantization_layer_zeropoint= quantization_layer_zeropoint;
        return layer;        
    }
    else{
        connected_layer layer = make_connected_layer(params.batch, 1, params.inputs, output, activation, batch_normalize);        
        return layer;        
    }
}

softmax_layer parse_softmax(texpar_list_t *options, size_params params)
{
    int quantization_type = texpar_find_int_quiet(options, "quantization_type",0);
    int groups = texpar_find_int_quiet(options, "groups", 1);
    if(quantization_type) {
        softmax_layer layer = make_quantized_softmax_layer(params.batch, params.inputs, groups,quantization_type);
        layer.temperature = texpar_find_float_quiet(options, "temperature", 1);
        char *tree_file = texpar_find_str(options, "tree", 0);
        if (tree_file) layer.softmax_tree = read_tree(tree_file);
        layer.w = params.w;
        layer.h = params.h;
        layer.c = params.c;
        layer.spatial = texpar_find_float_quiet(options, "spatial", 0);
        layer.noloss = texpar_find_int_quiet(options, "noloss", 0);
        return layer;    
    }
    else {
        softmax_layer layer = make_softmax_layer(params.batch, params.inputs, groups);
        layer.temperature = texpar_find_float_quiet(options, "temperature", 1);
        char *tree_file = texpar_find_str(options, "tree", 0);
        if (tree_file) layer.softmax_tree = read_tree(tree_file);
        layer.w = params.w;
        layer.h = params.h;
        layer.c = params.c;
        layer.spatial = texpar_find_float_quiet(options, "spatial", 0);
        layer.noloss = texpar_find_int_quiet(options, "noloss", 0);
        return layer;
    }
}

int *parse_yolo_mask(char *a, int *num)
{
    int *mask = 0;
    if (a) {
        int len = strlen(a);
        int n = 1;
        int i;
        for (i = 0; i < len; ++i) {
            if (a[i] == ',') ++n;
        }
        mask = (int*)calloc(n, sizeof(int));
        for (i = 0; i < n; ++i) {
            int val = atoi(a);
            mask[i] = val;
            a = strchr(a, ',') + 1;
        }
        *num = n;
    }
    return mask;
}

layer parse_yolo(texpar_list_t *options, size_params params)
{
    int classes = texpar_find_int(options, "classes", 20);
    int total = texpar_find_int(options, "num", 1);
    int num = total;

    char *a = texpar_find_str(options, "mask", 0);
    int *mask = parse_yolo_mask(a, &num);
    int max_boxes = texpar_find_int_quiet(options, "max", 90);
    layer l = make_yolo_layer(params.batch, params.w, params.h, num, total, mask, classes, max_boxes);
    if (l.outputs != params.inputs) {
        printf("Error: l.outputs == params.inputs \n");
        printf("filters= in the [convolutional]-layer doesn't correspond to classes= or mask= in [yolo]-layer \n");
        exit(1);
    }
    //assert(l.outputs == params.inputs);

    //l.max_boxes = texpar_find_int_quiet(options, "max", 90);
    l.jitter = texpar_find_float(options, "jitter", .2);
    l.focal_loss = texpar_find_int_quiet(options, "focal_loss", 0);

    l.ignore_thresh = texpar_find_float(options, "ignore_thresh", .5);
    l.truth_thresh = texpar_find_float(options, "truth_thresh", 1);
    l.random = texpar_find_int_quiet(options, "random", 0);

    char *map_file = texpar_find_str(options, "map", 0);
    if (map_file) l.map = read_map(map_file);

    a = texpar_find_str(options, "anchors", 0);
    if (a) {
        int len = strlen(a);
        int n = 1;
        int i;
        for (i = 0; i < len; ++i) {
            if (a[i] == ',') ++n;
        }
        for (i = 0; i < n && i < total*2; ++i) {
            float bias = atof(a);
            l.biases[i] = bias;
            a = strchr(a, ',') + 1;
        }
    }
    return l;
}

layer parse_region(texpar_list_t *options, size_params params)
{
    int coords = texpar_find_int(options, "coords", 4);
    int classes = texpar_find_int(options, "classes", 20);
    int num = texpar_find_int(options, "num", 1);
    int max_boxes = texpar_find_int_quiet(options, "max", 90);

    layer l = make_region_layer(params.batch, params.w, params.h, num, classes, coords, max_boxes);
    if (l.outputs != params.inputs) {
        printf("Error: l.outputs == params.inputs \n");
        printf("filters= in the [convolutional]-layer doesn't correspond to classes= or num= in [region]-layer \n");
        exit(1);
    }
    //assert(l.outputs == params.inputs);

    l.log = texpar_find_int_quiet(options, "log", 0);
    l.sqrt = texpar_find_int_quiet(options, "sqrt", 0);

    l.softmax = texpar_find_int(options, "softmax", 0);
    l.focal_loss = texpar_find_int_quiet(options, "focal_loss", 0);
    //l.max_boxes = texpar_find_int_quiet(options, "max",30);
    l.jitter = texpar_find_float(options, "jitter", .2);
    l.rescore = texpar_find_int_quiet(options, "rescore",0);

    l.thresh = texpar_find_float(options, "thresh", .5);
    l.classfix = texpar_find_int_quiet(options, "classfix", 0);
    l.absolute = texpar_find_int_quiet(options, "absolute", 0);
    l.random = texpar_find_int_quiet(options, "random", 0);

    l.coord_scale = texpar_find_float(options, "coord_scale", 1);
    l.object_scale = texpar_find_float(options, "object_scale", 1);
    l.noobject_scale = texpar_find_float(options, "noobject_scale", 1);
    l.mask_scale = texpar_find_float(options, "mask_scale", 1);
    l.class_scale = texpar_find_float(options, "class_scale", 1);
    l.bias_match = texpar_find_int_quiet(options, "bias_match",0);

    char *tree_file = texpar_find_str(options, "tree", 0);
    if (tree_file) l.softmax_tree = read_tree(tree_file);
    char *map_file = texpar_find_str(options, "map", 0);
    if (map_file) l.map = read_map(map_file);

    char *a = texpar_find_str(options, "anchors", 0);
    if(a){
        int len = strlen(a);
        int n = 1;
        int i;
        for(i = 0; i < len; ++i){
            if (a[i] == ',') ++n;
        }
        for(i = 0; i < n && i < num*2; ++i){
            float bias = atof(a);
            l.biases[i] = bias;
            a = strchr(a, ',')+1;
        }
    }
    return l;
}
detection_layer parse_detection(texpar_list_t *options, size_params params)
{
    int coords = texpar_find_int(options, "coords", 1);
    int classes = texpar_find_int(options, "classes", 1);
    int rescore = texpar_find_int(options, "rescore", 0);
    int num = texpar_find_int(options, "num", 1);
    int side = texpar_find_int(options, "side", 7);
    detection_layer layer = make_detection_layer(params.batch, params.inputs, num, side, classes, coords, rescore);

    layer.softmax = texpar_find_int(options, "softmax", 0);
    layer.sqrt = texpar_find_int(options, "sqrt", 0);

    layer.max_boxes = texpar_find_int_quiet(options, "max",30);
    layer.coord_scale = texpar_find_float(options, "coord_scale", 1);
    layer.forced = texpar_find_int(options, "forced", 0);
    layer.object_scale = texpar_find_float(options, "object_scale", 1);
    layer.noobject_scale = texpar_find_float(options, "noobject_scale", 1);
    layer.class_scale = texpar_find_float(options, "class_scale", 1);
    layer.jitter = texpar_find_float(options, "jitter", .2);
    layer.random = texpar_find_int_quiet(options, "random", 0);
    layer.reorg = texpar_find_int_quiet(options, "reorg", 0);
    return layer;
}

cost_layer parse_cost(texpar_list_t *options, size_params params)
{
    char *type_s = texpar_find_str(options, "type", "sse");
    COST_TYPE type = get_cost_type(type_s);
    float scale = texpar_find_float_quiet(options, "scale",1);
    cost_layer layer = make_cost_layer(params.batch, params.inputs, type, scale);
    layer.ratio =  texpar_find_float_quiet(options, "ratio",0);
    return layer;
}

crop_layer parse_crop(texpar_list_t *options, size_params params)
{
    int crop_height = texpar_find_int(options, "crop_height",1);
    int crop_width = texpar_find_int(options, "crop_width",1);
    int flip = texpar_find_int(options, "flip",0);
    float angle = texpar_find_float(options, "angle",0);
    float saturation = texpar_find_float(options, "saturation",1);
    float exposure = texpar_find_float(options, "exposure",1);

    int batch,h,w,c;
    h = params.h;
    w = params.w;
    c = params.c;
    batch=params.batch;
    if(!(h && w && c)) error("Layer before crop layer must output image.");

    int noadjust = texpar_find_int_quiet(options, "noadjust",0);

    crop_layer l = make_crop_layer(batch,h,w,c,crop_height,crop_width,flip, angle, saturation, exposure);
    l.shift = texpar_find_float(options, "shift", 0);
    l.noadjust = noadjust;
    return l;
}

layer parse_reorg(texpar_list_t *options, size_params params)
{
    int stride = texpar_find_int(options, "stride",1);
    int reverse = texpar_find_int_quiet(options, "reverse",0);

    int batch,h,w,c;
    h = params.h;
    w = params.w;
    c = params.c;
    batch=params.batch;
    if(!(h && w && c)) error("Layer before reorg layer must output image.");

    layer layer = make_reorg_layer(batch,w,h,c,stride,reverse);
    return layer;
}

layer parse_reorg_old(texpar_list_t *options, size_params params)
{
    printf("\n reorg_old \n");
    int stride = texpar_find_int(options, "stride", 1);
    int reverse = texpar_find_int_quiet(options, "reverse", 0);

    int batch, h, w, c;
    h = params.h;
    w = params.w;
    c = params.c;
    batch = params.batch;
    if (!(h && w && c)) error("Layer before reorg layer must output image.");

    layer layer = make_reorg_old_layer(batch, w, h, c, stride, reverse);
    return layer;
}

maxpool_layer parse_maxpool(texpar_list_t *options, size_params params)
{
    int quantization_type = texpar_find_int_quiet(options, "quantization_type",0);
    float quantization_layer_scale = texpar_find_float_quiet(options, "quantization_layer_scale",0);
    int quantization_layer_zeropoint = texpar_find_int_quiet(options, "quantization_layer_zeropoint",1);
  
    int stride = texpar_find_int(options, "stride",1);
    int size = texpar_find_int(options, "size",stride);
    int padding = texpar_find_int_quiet(options, "padding", size-1);

    int batch,h,w,c;
    h = params.h;
    w = params.w;
    c = params.c;
    batch=params.batch;
    if(!(h && w && c)) error("Layer before maxpool layer must output image.");
    if (quantization_type){
        printf("init q_maxpool\n");

        maxpool_layer layer = make_quantized_maxpool_layer(batch,h,w,c,size,stride,padding,quantization_type);
        //layer.maxpool_zero_nonmax = texpar_find_int_quiet(options, "maxpool_zero_nonmax", 0);
        layer.quantization_layer_scale= quantization_layer_scale;
        layer.quantization_layer_zeropoint= quantization_layer_zeropoint;
        return layer;
    }
    else{
        maxpool_layer layer = make_maxpool_layer(batch,h,w,c,size,stride,padding);
        return layer;
    }
}

avgpool_layer parse_avgpool(texpar_list_t *options, size_params params)
{
    int batch,w,h,c;
    w = params.w;
    h = params.h;
    c = params.c;
    batch=params.batch;
    if(!(h && w && c)) error("Layer before avgpool layer must output image.");

    avgpool_layer layer = make_avgpool_layer(batch,w,h,c);
    return layer;
}

dropout_layer parse_dropout(texpar_list_t *options, size_params params)
{
    float probability = texpar_find_float(options, "probability", .5);
    dropout_layer layer = make_dropout_layer(params.batch, params.inputs, probability);
    layer.out_w = params.w;
    layer.out_h = params.h;
    layer.out_c = params.c;
    return layer;
}

layer parse_normalization(texpar_list_t *options, size_params params)
{
    float alpha = texpar_find_float(options, "alpha", .0001);
    float beta =  texpar_find_float(options, "beta" , .75);
    float kappa = texpar_find_float(options, "kappa", 1);
    int size = texpar_find_int(options, "size", 5);
    layer l = make_normalization_layer(params.batch, params.w, params.h, params.c, size, alpha, beta, kappa);
    return l;
}

layer parse_batchnorm(texpar_list_t *options, size_params params)
{
    layer l = make_batchnorm_layer(params.batch, params.w, params.h, params.c);
    return l;
}

layer parse_shortcut(texpar_list_t *options, size_params params, network net)  //q_check
{
    int quantization_type = texpar_find_int_quiet(options, "quantization_type",0);
    float quantization_layer_scale = texpar_find_float_quiet(options, "quantization_layer_scale",0);
    int quantization_layer_zeropoint = texpar_find_int_quiet(options, "quantization_layer_zeropoint",1);
    char *l = texpar_find(options, "from");
    int index = atoi(l);
    if(index < 0) index = params.index + index;

    int batch = params.batch;
    layer from = net.layers[index];
    if (quantization_type){
        layer s = make_quantized_shortcut_layer(batch, index, params.w, params.h, params.c, from.out_w, from.out_h, from.out_c,quantization_type);
        s.quantization_layer_scale= quantization_layer_scale;
        s.quantization_layer_zeropoint= quantization_layer_zeropoint; 
        char *activation_s = texpar_find_str(options, "activation", "linear");
        ACTIVATION activation = get_activation(activation_s);
        s.activation = activation;
        return s;
    }
    else{
        layer s = make_shortcut_layer(batch, index, params.w, params.h, params.c, from.out_w, from.out_h, from.out_c);
        char *activation_s = texpar_find_str(options, "activation", "linear");
        ACTIVATION activation = get_activation(activation_s);
        s.activation = activation;
        return s;
    }

}


layer parse_activation(texpar_list_t *options, size_params params)
{
    char *activation_s = texpar_find_str(options, "activation", "linear");
    ACTIVATION activation = get_activation(activation_s);

    layer l = make_activation_layer(params.batch, params.inputs, activation);

    l.out_h = params.h;
    l.out_w = params.w;
    l.out_c = params.c;
    l.h = params.h;
    l.w = params.w;
    l.c = params.c;

    return l;
}

layer parse_upsample(texpar_list_t *options, size_params params, network net)
{

    int stride = texpar_find_int(options, "stride", 2);
    layer l = make_upsample_layer(params.batch, params.w, params.h, params.c, stride);
    l.scale = texpar_find_float_quiet(options, "scale", 1);
    return l;
}

route_layer parse_route(texpar_list_t *options, size_params params, network net)
{
    char *l = texpar_find(options, "layers");
    int len = strlen(l);
    if(!l) error("Route Layer must specify input layers");
    int n = 1;
    int i;
    for(i = 0; i < len; ++i){
        if (l[i] == ',') ++n;
    }

    int* layers = (int*)calloc(n, sizeof(int));
    int* sizes = (int*)calloc(n, sizeof(int));
    for(i = 0; i < n; ++i){
        int index = atoi(l);
        l = strchr(l, ',')+1;
        if(index < 0) index = params.index + index;
        layers[i] = index;
        sizes[i] = net.layers[index].outputs;
    }
    int batch = params.batch;

    route_layer layer = make_route_layer(batch, n, layers, sizes);

    convolutional_layer first = net.layers[layers[0]];
    layer.out_w = first.out_w;
    layer.out_h = first.out_h;
    layer.out_c = first.out_c;
    for(i = 1; i < n; ++i){
        int index = layers[i];
        convolutional_layer next = net.layers[index];
        if(next.out_w == first.out_w && next.out_h == first.out_h){
            layer.out_c += next.out_c;
        }else{
            layer.out_h = layer.out_w = layer.out_c = 0;
        }
    }

    return layer;
}

learning_rate_policy get_policy(char *s)
{
    if (strcmp(s, "random")==0) return RANDOM;
    if (strcmp(s, "poly")==0) return POLY;
    if (strcmp(s, "constant")==0) return CONSTANT;
    if (strcmp(s, "step")==0) return STEP;
    if (strcmp(s, "exp")==0) return EXP;
    if (strcmp(s, "sigmoid")==0) return SIG;
    if (strcmp(s, "steps")==0) return STEPS;
    if (strcmp(s, "sgdr")==0) return SGDR;
    printf("Couldn't find policy %s, going with constant\n", s);
    return CONSTANT;
}

void parse_net_options(texpar_list_t *options, network *net)
{
    net->quantization_type = texpar_find_int_quiet(options, "quantization_type", 0); //quan
    net->input_scale = texpar_find_float_quiet(options, "input_scale", 0);
    net->input_zeropoint = texpar_find_int_quiet(options, "input_zeropoint", 0);
    net->start_check_point = texpar_find_int_quiet(options, "start_check_point", 0);
    net->end_check_point = texpar_find_int_quiet(options, "end_check_point", 0);  
    net->normalize_mean_0 = texpar_find_float_quiet(options, "normalize_mean_0", 0);
    net->normalize_mean_1 = texpar_find_float_quiet(options, "normalize_mean_1", 0);
    net->normalize_mean_2 = texpar_find_float_quiet(options, "normalize_mean_2", 0);
    net->normalize_var_0 = texpar_find_float_quiet(options, "normalize_var_0", 0);
    net->normalize_var_1 = texpar_find_float_quiet(options, "normalize_var_1", 0);
    net->normalize_var_2 = texpar_find_float_quiet(options, "normalize_var_2", 0);     
    net->batch = texpar_find_int(options, "batch",1);
    net->learning_rate = texpar_find_float(options, "learning_rate", .001);
    net->learning_rate_min = texpar_find_float_quiet(options, "learning_rate_min", .00001);
    net->batches_per_cycle = texpar_find_int_quiet(options, "sgdr_cycle", 1000);
    net->batches_cycle_mult = texpar_find_int_quiet(options, "sgdr_mult", 2);
    net->momentum = texpar_find_float(options, "momentum", .9);
    net->decay = texpar_find_float(options, "decay", .0001);
    int subdivs = texpar_find_int(options, "subdivisions",1);
    net->time_steps = texpar_find_int_quiet(options, "time_steps",1);
    net->track = texpar_find_int_quiet(options, "track", 0);
    net->augment_speed = texpar_find_int_quiet(options, "augment_speed", 2);
    net->init_sequential_subdivisions = net->sequential_subdivisions = texpar_find_int_quiet(options, "sequential_subdivisions", subdivs);
    if (net->sequential_subdivisions > subdivs) net->init_sequential_subdivisions = net->sequential_subdivisions = subdivs;
    net->try_fix_nan = texpar_find_int_quiet(options, "try_fix_nan", 0);
    net->batch /= subdivs;
    net->batch *= net->time_steps;
    net->subdivisions = subdivs;

    net->adam = texpar_find_int_quiet(options, "adam", 0);
    if(net->adam){
        net->B1 = texpar_find_float(options, "B1", .9);
        net->B2 = texpar_find_float(options, "B2", .999);
        net->eps = texpar_find_float(options, "eps", .000001);
    }

    net->h = texpar_find_int_quiet(options, "height",0);
    net->w = texpar_find_int_quiet(options, "width",0);
    net->c = texpar_find_int_quiet(options, "channels",0);
    net->inputs = texpar_find_int_quiet(options, "inputs", net->h * net->w * net->c);
    net->max_crop = texpar_find_int_quiet(options, "max_crop",net->w*2);
    net->min_crop = texpar_find_int_quiet(options, "min_crop",net->w);
    net->flip = texpar_find_int_quiet(options, "flip", 1);
    net->blur = texpar_find_int_quiet(options, "blur", 0);

    net->angle = texpar_find_float_quiet(options, "angle", 0);
    net->aspect = texpar_find_float_quiet(options, "aspect", 1);
    net->saturation = texpar_find_float_quiet(options, "saturation", 1);
    net->exposure = texpar_find_float_quiet(options, "exposure", 1);
    net->hue = texpar_find_float_quiet(options, "hue", 0);
    net->power = texpar_find_float_quiet(options, "power", 4);

    if(!net->inputs && !(net->h && net->w && net->c)) error("No input parameters supplied");

    char *policy_s = texpar_find_str(options, "policy", "constant");
    net->policy = get_policy(policy_s);
    net->burn_in = texpar_find_int_quiet(options, "burn_in", 0);
    if(net->policy == STEP){
        net->step = texpar_find_int(options, "step", 1);
        net->scale = texpar_find_float(options, "scale", 1);
    } else if (net->policy == STEPS || net->policy == SGDR){
        char *l = texpar_find(options, "steps");
        char *p = texpar_find(options, "scales");
        char *s = texpar_find(options, "seq_scales");
        if(net->policy == STEPS && (!l || !p)) error("STEPS policy must have steps and scales in cfg file");

        if (l) {
            int len = strlen(l);
            int n = 1;
            int i;
            for (i = 0; i < len; ++i) {
                if (l[i] == ',') ++n;
            }
            int* steps = (int*)calloc(n, sizeof(int));
            float* scales = (float*)calloc(n, sizeof(float));
            float* seq_scales = (float*)calloc(n, sizeof(float));
            for (i = 0; i < n; ++i) {
                float scale = 1.0;
                if (p) {
                    scale = atof(p);
                    p = strchr(p, ',') + 1;
                }
                float sequence_scale = 1.0;
                if (s) {
                    sequence_scale = atof(s);
                    s = strchr(s, ',') + 1;
                }
                int step = atoi(l);
                l = strchr(l, ',') + 1;
                steps[i] = step;
                scales[i] = scale;
                seq_scales[i] = sequence_scale;
            }
            net->scales = scales;
            net->steps = steps;
            net->seq_scales = seq_scales;
            net->num_steps = n;
        }
    } else if (net->policy == EXP){
        net->gamma = texpar_find_float(options, "gamma", 1);
    } else if (net->policy == SIG){
        net->gamma = texpar_find_float(options, "gamma", 1);
        net->step = texpar_find_int(options, "step", 1);
    } else if (net->policy == POLY || net->policy == RANDOM){
        //net->power = texpar_find_float(options, "power", 1);
    }
    net->max_batches = texpar_find_int(options, "max_batches", 0);
}

int is_network(texpar_section_t *s)
{
    return (strcmp(s->type, "[net]")==0
            || strcmp(s->type, "[network]")==0);
}

network parse_network_cfg(char *filename)
{
    return parse_network_cfg_custom(filename, 0, 0);
}

network parse_network_cfg_custom(char *cfg, int batch, int time_steps)
{
    texpar_list_t *sections = texpar_read_file_with_section(cfg);
    texpar_iter_t *n = sections->front;
    if(!n) error("Config file has no sections");
    network net = make_network(sections->size - 1);
    size_params params;

    texpar_section_t *s = (texpar_section_t *)n->val;
    texpar_list_t *options = s->option_list;
    if(!is_network(s)) error("First texpar_section_t must be [net] or [network]");
    parse_net_options(options, &net);

    params.h = net.h;
    params.w = net.w;
    params.c = net.c;
    params.inputs = net.inputs;
    if (batch > 0) net.batch = batch;
    if (time_steps > 0) net.time_steps = time_steps;
    if (net.batch < net.time_steps) net.batch = net.time_steps;
    params.batch = net.batch;
    params.time_steps = net.time_steps;
    params.net = net;

    float bflops = 0;
    size_t workspace_size = 0;
    size_t max_inputs = 0;
    size_t max_outputs = 0;
    n = n->next;
    int count = 0;
    texpar_free_section(s);
    printf("layer     filters    size              input                output\n");
    while(n){
        if(net.end_check_point){
            if(count >=net.end_check_point)
                break;
        }
        params.index = count;
        printf("%4d ", count);
        s = (texpar_section_t *)n->val;
        options = s->option_list;
        layer l = { (LAYER_TYPE)0 };
        LAYER_TYPE lt = string_to_layer_type(s->type);
        if(0){
#ifdef USE_DARKNET_CONVOLUTIONAL_LAYER
        }else if(lt == CONVOLUTIONAL){
            l = parse_convolutional(options, params);
#endif
#ifdef USE_DARKNET_LOCAL_LAYER
        }else if(lt == LOCAL){
            l = parse_local(options, params);
#endif
#ifdef USE_DARKNET_ACTIVE_LAYER
        }else if(lt == ACTIVE){
            l = parse_activation(options, params);
#endif
#ifdef USE_DARKNET_RNN_LAYER
        }else if(lt == RNN){
            l = parse_rnn(options, params);
#endif
#ifdef USE_DARKNET_GRU_LAYER
        }else if(lt == GRU){
            l = parse_gru(options, params);
#endif
#ifdef USE_DARKNET_LSTM_LAYER
        }else if(lt == LSTM){
            l = parse_lstm(options, params);
#endif
#ifdef USE_DARKNET_CONV_LSTM_LAYER
        }else if(lt == CONV_LSTM) {
            l = parse_conv_lstm(options, params);
#endif
#ifdef USE_DARKNET_CRNN_LAYER
        }else if(lt == CRNN){
            l = parse_crnn(options, params);
#endif
#ifdef USE_DARKNET_CONNECTED_LAYER
        }else if(lt == CONNECTED){
            l = parse_connected(options, params);
#endif
#ifdef USE_DARKNET_CROP_LAYER
        }else if(lt == CROP){
            l = parse_crop(options, params);
#endif
#ifdef USE_DARKNET_COST_LAYER
        }else if(lt == COST){
            l = parse_cost(options, params);
#endif
#ifdef USE_DARKNET_REGION_LAYER
        }else if(lt == REGION){
            l = parse_region(options, params);
#endif
#ifdef USE_DARKNET_YOLO_LAYER
        }else if(lt == YOLO) {
            l = parse_yolo(options, params);
#endif
#ifdef USE_DARKNET_DETECTION_LAYER
        }else if(lt == DETECTION){
            l = parse_detection(options, params);
#endif
#ifdef USE_DARKNET_SOFTMAX_LAYER
        }else if(lt == SOFTMAX){
            l = parse_softmax(options, params);
            net.hierarchy = l.softmax_tree;
#endif
#ifdef USE_DARKNET_NORMALIZATION_LAYER
        }else if(lt == NORMALIZATION){
            l = parse_normalization(options, params);
#endif
#ifdef USE_DARKNET_BATCHNORM_LAYER
        }else if(lt == BATCHNORM){
            l = parse_batchnorm(options, params);
#endif
#ifdef USE_DARKNET_MAXPOOL_LAYER
        }else if(lt == MAXPOOL){
            l = parse_maxpool(options, params);
#endif
#ifdef USE_DARKNET_REORG_LAYER
        }else if(lt == REORG){
            l = parse_reorg(options, params);        }
        else if (lt == REORG_OLD) {
            l = parse_reorg_old(options, params);
#endif
#ifdef USE_DARKNET_AVGPOOL_LAYER
        }else if(lt == AVGPOOL){
            l = parse_avgpool(options, params);
#endif
#ifdef USE_DARKNET_ROUTE_LAYER
        }else if(lt == ROUTE){
            l = parse_route(options, params, net);
            int k;
            for (k = 0; k < l.n; ++k) net.layers[l.input_layers[k]].use_bin_output = 0;
#endif
#ifdef USE_DARKNET_UPSAMPLE_LAYER
        }else if(lt == UPSAMPLE) {
            l = parse_upsample(options, params, net);
#endif
#ifdef USE_DARKNET_SHORTCUT_LAYER
        }else if(lt == SHORTCUT){
            l = parse_shortcut(options, params, net);
            net.layers[count - 1].use_bin_output = 0;
            net.layers[l.index].use_bin_output = 0;
#endif
#ifdef USE_DARKNET_DROPOUT_LAYER
        }else if(lt == DROPOUT){
            l = parse_dropout(options, params);
            l.output = net.layers[count-1].output;
            l.delta = net.layers[count-1].delta;
#endif
        }else{
            printf("Type not recognized: %s\n", s->type);
        }
        l.onlyforward = texpar_find_int_quiet(options, "onlyforward", 0);
        l.stopbackward = texpar_find_int_quiet(options, "stopbackward", 0);
        l.dontload = texpar_find_int_quiet(options, "dontload", 0);
        l.dontloadscales = texpar_find_int_quiet(options, "dontloadscales", 0);
        l.learning_rate_scale = texpar_find_float_quiet(options, "learning_rate", 1);
        texpar_unused(options);
        net.layers[count] = l;
        if (l.workspace_size > workspace_size) workspace_size = l.workspace_size;
        if (l.inputs > max_inputs) max_inputs = l.inputs;
        if (l.outputs > max_outputs) max_outputs = l.outputs;
        texpar_free_section(s);
        n = n->next;
        ++count;
        if(n){
            params.h = l.out_h;
            params.w = l.out_w;
            params.c = l.out_c;
            params.inputs = l.outputs;
        }
        if (l.bflops > 0) bflops += l.bflops;
    }
    //free_list(sections);
    net.outputs = get_network_output_size(net);
    net.output = get_network_output(net);
    printf("Total BFLOPS %5.3f \n", bflops);

    if (workspace_size) {
        if(net.quantization_type){
        net.workspace = (unsigned char*)calloc(1, workspace_size);
        }
        else{
        net.workspace = (float*)calloc(1, workspace_size);
        }
    }

    LAYER_TYPE lt = net.layers[net.n - 1].type;
    if ((net.w % 32 != 0 || net.h % 32 != 0) && (lt == YOLO || lt == REGION || lt == DETECTION)) {
        printf("\n Warning: width=%d and height=%d in cfg-file must be divisible by 32 for default networks Yolo v1/v2/v3!!! \n\n",
            net.w, net.h);
    }
    return net;
}


void save_convolutional_weights_binary(layer l, FILE *fp)
{
    int size = (l.c/l.groups)*l.size*l.size;
    binarize_weights(l.weights, l.n, size, l.binary_weights);
    int i, j, k;
    fwrite(l.biases, sizeof(float), l.n, fp);
    if (l.batch_normalize){
        fwrite(l.scales, sizeof(float), l.n, fp);
        fwrite(l.rolling_mean, sizeof(float), l.n, fp);
        fwrite(l.rolling_variance, sizeof(float), l.n, fp);
    }
    for(i = 0; i < l.n; ++i){
        float mean = l.binary_weights[i*size];
        if(mean < 0) mean = -mean;
        fwrite(&mean, sizeof(float), 1, fp);
        for(j = 0; j < size/8; ++j){
            int index = i*size + j*8;
            unsigned char c = 0;
            for(k = 0; k < 8; ++k){
                if (j*8 + k >= size) break;
                if (l.binary_weights[index + k] > 0) c = (c | 1<<k);
            }
            fwrite(&c, sizeof(char), 1, fp);
        }
    }
}

void save_convolutional_weights(layer l, FILE *fp)
{
    if(l.binary){
        //save_convolutional_weights_binary(l, fp);
        //return;
    }
    int num = l.nweights;
    fwrite(l.biases, sizeof(float), l.n, fp);
    if (l.batch_normalize){
        fwrite(l.scales, sizeof(float), l.n, fp);
        fwrite(l.rolling_mean, sizeof(float), l.n, fp);
        fwrite(l.rolling_variance, sizeof(float), l.n, fp);
    }
    fwrite(l.weights, sizeof(float), num, fp);
    //if(l.adam){
    //    fwrite(l.m, sizeof(float), num, fp);
    //    fwrite(l.v, sizeof(float), num, fp);
    //}
}

void save_batchnorm_weights(layer l, FILE *fp)
{
    fwrite(l.scales, sizeof(float), l.c, fp);
    fwrite(l.rolling_mean, sizeof(float), l.c, fp);
    fwrite(l.rolling_variance, sizeof(float), l.c, fp);
}

void save_connected_weights(layer l, FILE *fp)
{
    fwrite(l.biases, sizeof(float), l.outputs, fp);
    fwrite(l.weights, sizeof(float), l.outputs*l.inputs, fp);
    if (l.batch_normalize){
        fwrite(l.scales, sizeof(float), l.outputs, fp);
        fwrite(l.rolling_mean, sizeof(float), l.outputs, fp);
        fwrite(l.rolling_variance, sizeof(float), l.outputs, fp);
    }
}

void save_weights_upto(network net, char *filename, int cutoff)
{
    printf("Saving weights to %s\n", filename);
    FILE *fp = ffopen(filename, "w");
    if(!fp) file_error(filename);

    int major = MAJOR_VERSION;
    int minor = MINOR_VERSION;
    int revision = PATCH_VERSION;
    fwrite(&major, sizeof(int), 1, fp);
    fwrite(&minor, sizeof(int), 1, fp);
    fwrite(&revision, sizeof(int), 1, fp);
    fwrite(net.seen, sizeof(uint64_t), 1, fp);

    int i;
    for(i = 0; i < net.n && i < cutoff; ++i){
        layer l = net.layers[i];
        if(l.type == CONVOLUTIONAL){
            save_convolutional_weights(l, fp);
        } if(l.type == CONNECTED){
            save_connected_weights(l, fp);
        } if(l.type == BATCHNORM){
            save_batchnorm_weights(l, fp);
        } if(l.type == RNN){
            save_connected_weights(*(l.input_layer), fp);
            save_connected_weights(*(l.self_layer), fp);
            save_connected_weights(*(l.output_layer), fp);
        } if(l.type == GRU){
            save_connected_weights(*(l.input_z_layer), fp);
            save_connected_weights(*(l.input_r_layer), fp);
            save_connected_weights(*(l.input_h_layer), fp);
            save_connected_weights(*(l.state_z_layer), fp);
            save_connected_weights(*(l.state_r_layer), fp);
            save_connected_weights(*(l.state_h_layer), fp);
        } if(l.type == LSTM){
            save_connected_weights(*(l.wf), fp);
            save_connected_weights(*(l.wi), fp);
            save_connected_weights(*(l.wg), fp);
            save_connected_weights(*(l.wo), fp);
            save_connected_weights(*(l.uf), fp);
            save_connected_weights(*(l.ui), fp);
            save_connected_weights(*(l.ug), fp);
            save_connected_weights(*(l.uo), fp);
        } if (l.type == CONV_LSTM) {
            if (l.peephole) {
                save_convolutional_weights(*(l.vf), fp);
                save_convolutional_weights(*(l.vi), fp);
                save_convolutional_weights(*(l.vo), fp);
            }
            save_convolutional_weights(*(l.wf), fp);
            save_convolutional_weights(*(l.wi), fp);
            save_convolutional_weights(*(l.wg), fp);
            save_convolutional_weights(*(l.wo), fp);
            save_convolutional_weights(*(l.uf), fp);
            save_convolutional_weights(*(l.ui), fp);
            save_convolutional_weights(*(l.ug), fp);
            save_convolutional_weights(*(l.uo), fp);
        } if(l.type == CRNN){
            save_convolutional_weights(*(l.input_layer), fp);
            save_convolutional_weights(*(l.self_layer), fp);
            save_convolutional_weights(*(l.output_layer), fp);
        } if(l.type == LOCAL){
            int locations = l.out_w*l.out_h;
            int size = l.size*l.size*l.c*l.n*locations;
            fwrite(l.biases, sizeof(float), l.outputs, fp);
            fwrite(l.weights, sizeof(float), size, fp);
        }
    }
    ffclose(fp);
}
void save_weights(network net, char *filename)
{
    save_weights_upto(net, filename, net.n);
}

void transpose_matrix(float *a, int rows, int cols)
{
    float* transpose = (float*)calloc(rows * cols, sizeof(float));
    int x, y;
    for(x = 0; x < rows; ++x){
        for(y = 0; y < cols; ++y){
            transpose[y*rows + x] = a[x*cols + y];
        }
    }
    memcpy(a, transpose, rows*cols*sizeof(float));
    free(transpose);
}


void load_connected_weights(layer l, FAKEFILE *weights, int transpose) ///q_check
{
    if(l.quantization_type){  //tranpose and batchnorm x
        ffread(l.quantized_weights, sizeof(char), l.outputs*l.inputs, weights);
        ffread(l.M0_int32, sizeof(int), l.outputs, weights);
        ffread(l.right_shift, sizeof(char), l.outputs, weights);
        ffread(l.quantization_per_channel_zeropoint, sizeof(int), l.outputs, weights);
        ffread(l.biases_int32, sizeof(int), l.outputs, weights);
        printf("1\n");
    }
    else{
        ffread(l.biases, sizeof(float), l.outputs, weights);
        ffread(l.weights, sizeof(float), l.outputs*l.inputs, weights);
        if(transpose){
            transpose_matrix(l.weights, l.inputs, l.outputs);
        }
    }

    //printf("Biases: %f mean %f variance\n", mean_array(l.biases, l.outputs), variance_array(l.biases, l.outputs));
    //printf("Weights: %f mean %f variance\n", mean_array(l.weights, l.outputs*l.inputs), variance_array(l.weights, l.outputs*l.inputs));
    if (l.batch_normalize && (!l.dontloadscales)){
        ffread(l.scales, sizeof(float), l.outputs, weights);
        ffread(l.rolling_mean, sizeof(float), l.outputs, weights);
        ffread(l.rolling_variance, sizeof(float), l.outputs, weights);
        //printf("Scales: %f mean %f variance\n", mean_array(l.scales, l.outputs), variance_array(l.scales, l.outputs));
        //printf("rolling_mean: %f mean %f variance\n", mean_array(l.rolling_mean, l.outputs), variance_array(l.rolling_mean, l.outputs));
        //printf("rolling_variance: %f mean %f variance\n", mean_array(l.rolling_variance, l.outputs), variance_array(l.rolling_variance, l.outputs));
    }
}

void load_batchnorm_weights(layer l, FAKEFILE *weights)
{
    ffread(l.scales, sizeof(float), l.c, weights);
    ffread(l.rolling_mean, sizeof(float), l.c, weights);
    ffread(l.rolling_variance, sizeof(float), l.c, weights);
}

void load_convolutional_weights_binary(layer l, FAKEFILE *fp)
{
    ffread(l.biases, sizeof(float), l.n, fp);
    if (l.batch_normalize && (!l.dontloadscales)){
        ffread(l.scales, sizeof(float), l.n, fp);
        ffread(l.rolling_mean, sizeof(float), l.n, fp);
        ffread(l.rolling_variance, sizeof(float), l.n, fp);
    }
    int size = (l.c / l.groups)*l.size*l.size;
    int i, j, k;
    for(i = 0; i < l.n; ++i){
        float mean = 0;
        ffread(&mean, sizeof(float), 1, fp);
        for(j = 0; j < size/8; ++j){
            int index = i*size + j*8;
            unsigned char c = 0;
            ffread(&c, sizeof(char), 1, fp);
            for(k = 0; k < 8; ++k){
                if (j*8 + k >= size) break;
                l.weights[index + k] = (c & 1<<k) ? mean : -mean;
            }
        }
    }
}

void load_convolutional_weights(layer l, FAKEFILE *weights)  // q_check
{
    if(l.binary){
        //load_convolutional_weights_binary(l, fp);
        //return;
    }
    int num = l.nweights;
    if (l.quantization_type){
        if (l.batch_normalize && (!l.dontloadscales)){

            ffread(l.scales, sizeof(float), l.n, weights);
            ffread(l.rolling_mean, sizeof(float), l.n, weights);
            ffread(l.rolling_variance, sizeof(float), l.n, weights);
            if(0){
                int i;
                for(i = 0; i < l.n; ++i){
                    printf("%g, ", l.rolling_mean[i]);
                }
                printf("\n");
                for(i = 0; i < l.n; ++i){
                    printf("%g, ", l.rolling_variance[i]);
                }
                printf("\n");
            }
            if(0){
                fill_cpu(l.n, 0, l.rolling_mean, 1);
                fill_cpu(l.n, 0, l.rolling_variance, 1);
            }
        }
        printf("load q_weight start\n");
        ffread(l.quantized_weights, sizeof(char), num, weights);
        ffread(l.M0_int32, sizeof(int), l.n, weights);
        ffread(l.right_shift, sizeof(char), l.n, weights);
        ffread(l.quantization_per_channel_zeropoint, sizeof(int), l.n, weights);
        ffread(l.biases_int32, sizeof(int), l.n, weights);
        if (l.flipped) {
            transpose_matrix(l.quantized_weights, (l.c/l.groups)*l.size*l.size, l.n);
        }        
    }
    else{
        ffread(l.biases, sizeof(float), l.n, weights);
        //ffread(l.weights, sizeof(float), num, weights); // as in connected layer
        if (l.batch_normalize && (!l.dontloadscales)){

            ffread(l.scales, sizeof(float), l.n, weights);
            ffread(l.rolling_mean, sizeof(float), l.n, weights);
            ffread(l.rolling_variance, sizeof(float), l.n, weights);
            if(0){
                int i;
                for(i = 0; i < l.n; ++i){
                    printf("%g, ", l.rolling_mean[i]);
                }
                printf("\n");
                for(i = 0; i < l.n; ++i){
                    printf("%g, ", l.rolling_variance[i]);
                }
                printf("\n");
            }
            if(0){
                fill_cpu(l.n, 0, l.rolling_mean, 1);
                fill_cpu(l.n, 0, l.rolling_variance, 1);
            }
        }
        ffread(l.weights, sizeof(float), num, weights);
        //if(l.adam){
        //    ffread(l.m, sizeof(float), num, weights);
        //    ffread(l.v, sizeof(float), num, weights);
        //}
        //if(l.c == 3) scal_cpu(num, 1./256, l.weights, 1);
        if (l.flipped) {
            transpose_matrix(l.weights, (l.c/l.groups)*l.size*l.size, l.n);
        }
    }
    //if (l.binary) binarize_weights(l.weights, l.n, (l.c/l.groups)*l.size*l.size, l.weights);
}
void load_quantized_shortcut_weights(layer l, FAKEFILE *weights) //q_check
{
    int num = l.nweights;
    int read_bytes;

    printf("load q_shortcut_weight start\n");
    printf("num = %d\n",num);
    ffread(l.quantized_weights, sizeof(char), num, weights);
    printf("qconv_weight[0]=%d\n",l.quantized_weights[0]);
    ffread(l.M0_int32, sizeof(int), l.out_c, weights);
    printf("qconv_per_channel_scale[0]=%d\n",l.M0_int32[0]);
    ffread(l.right_shift, sizeof(char), l.out_c, weights);
    printf("qconv_per_channel_scale[0]=%d\n",l.right_shift[0]);
    ffread(l.quantization_per_channel_zeropoint, sizeof(int), l.out_c, weights);
    printf("qconv_per_zeropoint[0]=%d\n",l.quantization_per_channel_zeropoint[0]);
    ffread(l.biases_int32, sizeof(int), l.out_c, weights);
    printf("qconv_bias[0]=%d\n",l.biases_int32[0]);
    //for (int i = 0; i < l.nweights; ++i) printf(" %f, ", l.weights[i]);
    //printf(" read_bytes = %d \n\n", read_bytes);
// #ifdef GPU
//     if (gpu_index >= 0) {
//         push_shortcut_layer(l);
//     }
// #endif
}

void load_weights_upto(network *net, char *filename, int cutoff)
{
    int major;
    int minor;
    int revision;

    FAKEFILE *weights = ffopen(filename, "r");

    ffread(&major, sizeof(int), 1, weights);
    ffread(&minor, sizeof(int), 1, weights);
    ffread(&revision, sizeof(int), 1, weights);
    if ((major * 10 + minor) >= 2) {
        printf("\n seen 64 \n");
        uint64_t iseen = 0;
        ffread(&iseen, sizeof(uint64_t), 1, weights);
        *net->seen = iseen;
    }
    else {
        printf("\n seen 32 \n");
        uint32_t iseen = 0;
        ffread(&iseen, sizeof(uint32_t), 1, weights);
        *net->seen = iseen;
    }
    int transpose = (major > 1000) || (minor > 1000);

    int i;
    for(i = 0; i < net->n && i < cutoff; ++i){
        layer l = net->layers[i];
        if (l.dontload)
          continue;
        //printf("%d layer \n",i);
        if(0){
#ifdef USE_DARKNET_CONVOLUTIONAL_LAYER
        }else if(l.type == CONVOLUTIONAL){
            load_convolutional_weights(l, weights);
#endif
#ifdef USE_DARKNET_SHORTCUT_LAYER
        }else if(l.type == SHORTCUT && l.nweights > 0) {
            printf("load_shortcut\n");
            load_quantized_shortcut_weights(l, weights);
#endif
#ifdef USE_DARKNET_CONNECTED_LAYER
        }else if(l.type == CONNECTED){
            load_connected_weights(l, weights, transpose);
#endif
#ifdef USE_DARKNET_BATCHNORM_LAYER
        }else if(l.type == BATCHNORM){
            load_batchnorm_weights(l, weights);
#endif
#ifdef USE_DARKNET_CRNN_LAYER
        }else if(l.type == CRNN){
            load_convolutional_weights(*(l.input_layer), weights);
            load_convolutional_weights(*(l.self_layer), weights);
            load_convolutional_weights(*(l.output_layer), weights);
#endif
#ifdef USE_DARKNET_RNN_LAYER
        }else if(l.type == RNN){
            load_connected_weights(*(l.input_layer), weights, transpose);
            load_connected_weights(*(l.self_layer), weights, transpose);
            load_connected_weights(*(l.output_layer), weights, transpose);
#endif
#ifdef USE_DARKNET_GRU_LAYER
        }else if(l.type == GRU){
            load_connected_weights(*(l.input_z_layer), weights, transpose);
            load_connected_weights(*(l.input_r_layer), weights, transpose);
            load_connected_weights(*(l.input_h_layer), weights, transpose);
            load_connected_weights(*(l.state_z_layer), weights, transpose);
            load_connected_weights(*(l.state_r_layer), weights, transpose);
            load_connected_weights(*(l.state_h_layer), weights, transpose);
#endif
#ifdef USE_DARKNET_LSTM_LAYER
        }else if(l.type == LSTM){
            load_connected_weights(*(l.wf), weights, transpose);
            load_connected_weights(*(l.wi), weights, transpose);
            load_connected_weights(*(l.wg), weights, transpose);
            load_connected_weights(*(l.wo), weights, transpose);
            load_connected_weights(*(l.uf), weights, transpose);
            load_connected_weights(*(l.ui), weights, transpose);
            load_connected_weights(*(l.ug), weights, transpose);
            load_connected_weights(*(l.uo), weights, transpose);
#endif
#ifdef USE_DARKNET_CONV_LSTM_LAYER
        }else if (l.type == CONV_LSTM) {
            if (l.peephole) {
                load_convolutional_weights(*(l.vf), weights);
                load_convolutional_weights(*(l.vi), weights);
                load_convolutional_weights(*(l.vo), weights);
            }
            load_convolutional_weights(*(l.wf), weights);
            load_convolutional_weights(*(l.wi), weights);
            load_convolutional_weights(*(l.wg), weights);
            load_convolutional_weights(*(l.wo), weights);
            load_convolutional_weights(*(l.uf), weights);
            load_convolutional_weights(*(l.ui), weights);
            load_convolutional_weights(*(l.ug), weights);
            load_convolutional_weights(*(l.uo), weights);
#endif
#ifdef USE_DARKNET_LOCAL_LAYER
        }else if(l.type == LOCAL){
            int locations = l.out_w*l.out_h;
            int size = l.size*l.size*l.c*l.n*locations;
            ffread(l.biases, sizeof(float), l.outputs, weights);
            ffread(l.weights, sizeof(float), size, weights);
#endif
        }
    }
    printf("load weight is Done!\n");
    ffclose(weights);
}

void load_weights(network *net, char *filename)
{
    if(net->end_check_point) {
        net->n = net->end_check_point;
        load_weights_upto(net, filename, net->end_check_point);
    }    
    else load_weights_upto(net, filename, net->n);
}

// load network & force - set batch size
network *load_network_custom(char *cfg, char *weights, int clear, int batch)
{
    printf(" Try to load cfg: %s, weights: %s, clear = %d \n", cfg, weights, clear);
    network* net = (network*)calloc(1, sizeof(network));
    *net = parse_network_cfg_custom(cfg, batch, 0);
    if (weights && weights[0] != 0) {
        load_weights(net, weights);
    }
    if (clear) (*net->seen) = 0;
    return net;
}

// load network & get batch size from cfg-file
network *load_network(char *cfg, char *weights, int clear)
{
    printf(" Try to load cfg: %s, weights: %s, clear = %d \n", cfg, weights, clear);
    network* net = (network*)calloc(1, sizeof(network));
    *net = parse_network_cfg(cfg);
    if (weights && weights[0] != 0) {
        load_weights(net, weights);
    }
    if (clear) (*net->seen) = 0;
    return net;
}
